const uploadService = require('./services/upload');

uploadService();